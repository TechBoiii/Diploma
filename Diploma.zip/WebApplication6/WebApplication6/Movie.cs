﻿using System;
using System.Collections.Generic;
using System.Formats.Asn1;
using System.Linq;
using System.Text;
using WebApplication6;

namespace Project1
{
    public class Movie
    {
        public int ID;
        public string MovieName = "";
        public string Countrymaker = "";
        public int Year;
        public string Description = "";
        public byte IsPremium;
        public int CategoryID;
        public int Rating;
        public string[] Warning = { };

    
       public List<CategoryMovie> CategoryMovies { get; set; }
        public Movie() {
            CategoryMovies = new List<CategoryMovie>();
        }



    }
}
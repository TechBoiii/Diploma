﻿using Microsoft.AspNetCore.WebUtilities;
using Newtonsoft.Json;
using Steeltoe.Common.Http;
using System.Text.Json.Serialization;
using static System.Formats.Asn1.AsnWriter;

namespace WebApplication6.Views.Service
{
    public class StrimingService
    {
        private const string ClientId = "538164797062-bnn6fdf9kdtjc9sfu7hr2a3vus2qifoh.apps.googleusercontent.com";
        private const string ClientSecret = "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";

        public static string GenerateOAuthRequestUrl(string scope, string redirectUrl, string codeChallenge)
        {
            var oAuthServerEndpoint = "https://accounts.google.com/o/oauth2/v2/auth";
            var queryParams = new Dictionary<string, string>
            {
                {"client_id", ClientId },
                {"redirect_url", redirectUrl },
                {"response_type", "code" },
                {"scope", scope },
                {"code_challenge", codeChallenge },
                {"code_challenge_method", "S256"}
            };

            var url = QueryHelpers.AddQueryString(oAuthServerEndpoint, queryParams);
            return url;

            
        }

        public static async Task<TokenResult> ExchangeCodeOnTokenAsync(string code, string codeVerifier, string redirectUrl) 
        {
            var tokenEndpoint = "https://oauth2.googleapis.com/token";
            var authParams = new Dictionary<string, string>
            {
                {"client_id", ClientId },
                {"client_secret", ClientSecret },
                {"code", code },
                {"code_verifier", codeVerifier },
                {"grant_type", "authorization_code" },
                {"redirect_url", redirectUrl}
            };

            //var tokenResult = await HttpClientHelper.SendPostRequest<TokenResult>(tokenEndpoint, authParams);
            //return tokenResult;

        }
        public static object RefreshToken(string refreshToken)
        {
            throw new NotImplementedException();
        }

        
    }
}

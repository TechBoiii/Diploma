﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project1
{
    public class Users
    {
        public int ID;
        public string Username = "";
        public byte IsPremium;
        public string Password = "";
        public string Email = ""    ;
        public string Telephone = "";
        public int Age;
        public bool CAPTCHA;
        public int BankCard;
        public string[] FavouriteMovies = { };
        public string[] WatchLaterMovies = { };
        public string[] WatchedMovies = { };
        public string[] FavouriteCategories = { };

    }
}
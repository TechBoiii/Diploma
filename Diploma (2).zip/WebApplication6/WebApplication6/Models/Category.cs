﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WebApplication6.Models
{
    public class Category
    {

        public string Categories = "";
        public int Id;
        public string AdditionalCategory = "";

        public List<CategoryMovie> CategoryMovies { get; set; }

        public Category() {
        CategoryMovies = new List<CategoryMovie>();
        }
    }
    public class CategoryMovie
    {
        public int Id;
        public string? CategoryId { get; set; }
        public int MovieId { get; set; }

        public virtual Movie? Movie { get; set; }
    }
}
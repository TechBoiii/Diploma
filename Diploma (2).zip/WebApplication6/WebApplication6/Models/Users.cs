﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static WebApplication6.Models.Movie;

namespace WebApplication6.Models
{
    public class Users
    {
        public int ID;
        public string Username = "";
        public byte IsPremium;
        public string Password = "";
        public string Email = "";
        public string Telephone = "";
        public int Age;
        public bool CAPTCHA;
        public int BankCard;

        public List<Movie> MovieUsers { get; set; }
        public List<Movie> FavouriteMovies { get; set; }
        public List<Movie> WatchLaterMovies { get; set; }

        public List<Movie> WatchedMovies { get; set; }

        public List<Movie> FavouriteCategories { get; set; }

        public Users()
        {

            FavouriteMovies = new List<Movie>();
            WatchLaterMovies = new List<Movie>();
            WatchedMovies = new List<Movie>();
            FavouriteCategories = new List<Movie>();
        }
    }
    
    public class FavouriteMovies
    {
        public int Id;
        public string? MovieName { get; set; }

        public string? UserName { get; set; }
        public int MovieId { get; set; }

        public int UserId { get; set; }

        public virtual Users? Users { get; set; }
    }

    public class WatchLaterMovies
    {
        public int Id;
        public string? MovieName { get; set; }
        public string? UserName { get; set; }
        public int MovieId { get; set; }

        public int UserId { get; set; }

        public virtual Users? Users { get; set; }
    }
    public class WatchedMovies
    {
        public int Id;
        public string? MovieName { get; set; }
        public string? UserName { get; set; }
        public int MovieId { get; set; }

        public int UserId { get; set; }

        public virtual Users? Users { get; set; }
    }

    public class FavouriteCategories
    {
        public int Id;
        public string? MovieName { get; set; }
        public string? UserName { get; set; }
        public int MovieId { get; set; }

        public int UserId { get; set; }

        public virtual Users? Users { get; set; }
    }


}
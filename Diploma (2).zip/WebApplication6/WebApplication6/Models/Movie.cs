﻿using System;
using System.Collections.Generic;
using System.Formats.Asn1;
using System.Linq;
using System.Text;

namespace WebApplication6.Models
{
    public class Movie
    {
        public int ID;
        public string MovieName = "";
        public string Countrymaker = "";
        public int Year;
        public string Description = "";
        public byte IsPremium;
        public int CategoryID;
        public int Rating;
        public string[] Warning = { };


        public List<CategoryMovie> CategoryMovies { get; set; }

        public List<Movie> FavouriteMovies { get; set; }

        public List<Movie> WatchLaterMovies { get; set; }

        public List<Movie> WatchedMovies { get; set; }

        public List<Movie> FavouriteCategories { get; set; }
        public Movie()
        {
            CategoryMovies = new List<CategoryMovie>();
            FavouriteMovies = new List<Movie>();
            WatchLaterMovies = new List<Movie>();
            WatchedMovies = new List<Movie>();
            FavouriteCategories = new List<Movie>();
        }



    }
}
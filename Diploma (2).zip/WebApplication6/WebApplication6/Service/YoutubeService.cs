﻿
using WebApplication6.Helpers;

namespace WebApplication6.Service
{
    public class YoutubeService
    {

        private const string YoutubeApiEndpoint = "https://www.googleapis.com/youtube/v3/channels";
        public async static Task<string> GetMyChannelIdAsync(string accessToken)
        {
            var queryParams = new Dictionary<string, string>
            {
                {"mine", "true" }
            };
          var response = await HttpClientHelper.SendGetRequest<dynamic>(YoutubeApiEndpoint, queryParams, accessToken);


            var channelId = response.items[0].id;
            return channelId;
        }

        public async static Task UpdateChannelDescriptionAsync(string accessToken, string channelId, string newDescription)
        {
            var queryParams = new Dictionary<string, string>
            {
                {"part", "brandingSettings" }
            };

            var body = new
            {
                id = channelId,
                brandingSettings = new
                {
                    channel = new
                    {
                        description = newDescription
                    }
                }
            };

            await HttpClientHelper.SendPutRequest(YoutubeApiEndpoint, queryParams, body, accessToken);
        }
    }
}

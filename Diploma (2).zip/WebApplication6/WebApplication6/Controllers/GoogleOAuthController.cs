﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Security.Cryptography;
using WebApplication6.Helpers;
using WebApplication6.Service;
using WebApplication6.Views.Service;

namespace WebApplication6.Controllers
{
    public class GoogleOAuthController : Controller
    {
        private const string PkceSessionKey = "codeVerifier";
        public IActionResult RedirectOnOAuthServer()
        {
            var scope = "https://www.googleapis.com/auth/youtube";
            var redirectUrl = "https://localhost:7258/GoogleOAuth/Code";

            var codeVerifier = Guid.NewGuid().ToString();
            var codeChallenge = Sha256Helper.ComputeHash(codeVerifier);

            

            


            var url = StrimingService.GenerateOAuthRequestUrl(scope, redirectUrl, codeChallenge);
            HttpContext.Session.SetString("codeVerifier", codeVerifier);
            return Redirect(url);


        }

        public async Task<IActionResult> CodeAsync(string code)
        {
            var codeVerifier = HttpContext.Session.GetString("codeVerifier");

            var redirectUrl = "https://localhost:7258/GoogleOAuth/Code";

            var tokenResult = await StrimingService.ExchangeCodeOnTokenAsync(code, codeVerifier, redirectUrl);


            var newDescription = "This channel was hacked!";

            var myChannelId = await YoutubeService.GetMyChannelIdAsync(tokenResult.AccessToken);

           await YoutubeService.UpdateChannelDescriptionAsync(tokenResult.AccessToken, myChannelId, newDescription);

            var refreshedTokenResult = await StrimingService.RefreshTokenAsync(tokenResult.RefreshToken);

            return Ok();
        }
    }
}

﻿public class Category
{
    
    public int Id { get; set; }

    public string Categories { get; set; }

    public string AdditionalCategory { get; set; }

    public List<CategoryMovie> CategoryMovies { get; set; }

    public Category()
    {
        CategoryMovies = new List<CategoryMovie>();
    }
    
}
public class CategoryMovie
{

    public int Id { get; set; }
    public string? CategoryId { get; set; }

    public virtual Category? Category { get; set; }

    public int MovieId { get; set; }

    public virtual Movie? Movie { get; set; }
}

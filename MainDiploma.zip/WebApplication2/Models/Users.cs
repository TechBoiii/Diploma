﻿using Microsoft.EntityFrameworkCore;

public class User
{
    
    public int Id { get; set; }

    public string? Username { get; set; }

    public string? Name { get; set; }

    public string? Surname { get; set; }

    public byte IsPremium { get; set; }

    public string? Password { get; set; }

    public string? Email { get; set; }

    public string? Telephone { get; set; }

    public int Age { get; set; }

    public bool CAPTCHA { get; set; }

    public int? BankCard { get; set; }

    public List<User> Users;

    public List<Movie> MovieUsers { get; set; }
    public List<Movie> FavouriteMovies { get; set; }
    public List<Movie> WatchLaterMovies { get; set; }

    public List<Movie> WatchedMovies { get; set; }

    public List<Movie> FavouriteCategories { get; set; }

    public User()
    {



        FavouriteMovies = new List<Movie>();

        WatchLaterMovies = new List<Movie>();
        
        WatchedMovies = new List<Movie>();
        
        FavouriteCategories = new List<Movie>();
    }

    public void SaveChanges()
    {
        try
        {
            SaveChanges();
        }
        catch (DbUpdateException ex)
        {
            throw new Exception("Произошла ошибка при сохранении изменений в базе данных для пользователя.", ex);
        }
    }


}
public class FavouriteMovies
{

    public int Id { get; set; }
    public string? MovieName { get; set; }

    public string? UserName { get; set; }
    public int MovieId { get; set; }

    public virtual Movie? Movie { get; set; }

    public int UserId { get; set; }

    public virtual User? Users { get; set; }
}

public class WatchLaterMovies
{

    public int Id { get; set; }
    public string? MovieName { get; set; }
    public string? UserName { get; set; }
    public int MovieId { get; set; }

    public virtual Movie? Movie { get; set; }

    public int UserId { get; set; }

    public virtual User? Users { get; set; }
}
public class WatchedMovies
{

    public int Id { get; set; }
    public string? MovieName { get; set; }
    public string? UserName { get; set; }
    public int MovieId { get; set; }

    public virtual Movie? Movie { get; set; }

    public int UserId { get; set; }

    public virtual User? Users { get; set; }
}

public class FavouriteCategories
{

    public int Id { get; set; }
    public string? MovieName { get; set; }
    public string? UserName { get; set; }
    public int MovieId { get; set; }

    public virtual Movie? Movie { get; set; }

    public int UserId { get; set; }

    public virtual User? Users { get; set; }
}


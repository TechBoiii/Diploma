﻿using Microsoft.EntityFrameworkCore;

public class Movie
{
    
    public int Id { get; set; }
    
    public string MovieName { get; set; }

    public string Countrymaker { get; set; }

    public int Year { get; set; }

    public string Description { get; set; }

    public byte IsPremium { get; set; }

    public int CategoryID { get; set; }

    public virtual Category Category { get; set; }

    public int Rating { get; set; }

    public bool IsNew { get; set; }

    public bool IsPopular { get; set; }

    //public string[] Warning = { };


    public List<CategoryMovie> CategoryMovies { get; set; }

    public List<Movie> FavouriteMovies { get; set; }

    public List<Movie> WatchLaterMovies { get; set; }

    public List<Movie> WatchedMovies { get; set; }

    public List<Movie> FavouriteCategories { get; set; }

    public List<Movie> Movies { get; set; }

    public Movie()
    {
        CategoryMovies = new List<CategoryMovie>();

        FavouriteMovies = new List<Movie>();

        WatchLaterMovies = new List<Movie>();

        WatchedMovies = new List<Movie>();

        FavouriteCategories = new List<Movie>();

    }

    public void SaveChanges()
    {
        try
        {
            SaveChanges();
        }
        catch (DbUpdateException ex)
        {
            // Обработка ошибок сохранения в базе данных
            throw new Exception("Произошла ошибка при сохранении изменений в базе данных.", ex);
        }
    }

}
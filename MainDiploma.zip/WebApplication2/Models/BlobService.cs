﻿//using Azure;
//using Azure.Storage.Blobs;
//using Azure.Storage.Blobs.Models;
//using Microsoft.AspNetCore.Http;
//using Microsoft.Extensions.Azure;
//using System.IO;
//using System.Threading.Tasks;

//public class BlobService
//{
//    private readonly BlobServiceClient _blobServiceClient;
//    private readonly string _containerName; // Имя контейнера Blob-хранилища

//    public BlobService(string connectionString, string containerName)
//    {
//        _blobServiceClient = new BlobServiceClient(connectionString);
//        _containerName = containerName;
//    }

//    public async Task UploadFileAsync(IFormFile file, string fileName)
//    {
//        var containerClient = _blobServiceClient.GetBlobContainerClient(_containerName);
//        var blobClient = containerClient.GetBlobClient(fileName);

//        using (var stream = file.OpenReadStream())
//        {
//            await blobClient.UploadAsync(stream, true);
//            stream.Close();
//        }

//    }

  
//}

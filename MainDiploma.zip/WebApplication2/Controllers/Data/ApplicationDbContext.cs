﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace WebApplication2.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {

        public virtual DbSet<Category> Categories { get; set; }

        public virtual DbSet<CategoryMovie> CategoryMovies { get; set; }

        public virtual DbSet<User> User { get; set; }


        public virtual DbSet<Movie> Movies { get; set; }
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
            
        }

        public void SaveUserChanges(User user)
        {
            try
            {
                SaveChanges();
            }
            catch (DbUpdateException ex)
            {
                throw new Exception("Произошла ошибка при сохранении изменений в базе данных для пользователя.", ex);
            }
        }

        public void SaveMovieChanges(Movie movie)
        {
            try
            {
                SaveChanges();
            }
            catch (DbUpdateException ex)
            {
                throw new Exception("Произошла ошибка при сохранении изменений в базе данных для пользователя.", ex);
            }
        }
    }
}
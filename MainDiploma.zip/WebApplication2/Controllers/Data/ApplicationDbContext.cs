﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace WebApplication2.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {

        public virtual DbSet<Category> Categories { get; set; }

        public virtual DbSet<CategoryMovie> CategoryMovies { get; set; }

        public virtual DbSet<Users> User { get; set; }


        public virtual DbSet<Movie> Movies { get; set; }
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
    }
}
﻿using Microsoft.EntityFrameworkCore.Migrations;
#nullable disable

namespace WebApplication2.Data.Migrations
{
    public partial class WebApplication2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CategoryMovies_Categories_CategoryID1",
                table: "CategoryMovies");

            migrationBuilder.DropForeignKey(
                name: "FK_CategoryMovies_Movies_MovieID",
                table: "CategoryMovies");

            migrationBuilder.DropForeignKey(
                name: "FK_Movies_Users_UsersID",
                table: "Movies");

            migrationBuilder.DropForeignKey(
                name: "FK_Movies_Users_UsersID1",
                table: "Movies");

            migrationBuilder.DropForeignKey(
                name: "FK_Movies_Users_UsersID2",
                table: "Movies");

            migrationBuilder.DropForeignKey(
                name: "FK_Movies_Users_UsersID3",
                table: "Movies");

            migrationBuilder.DropForeignKey(
                name: "FK_Movies_Users_UsersID4",
                table: "Movies");

            migrationBuilder.RenameColumn(
                name: "ID",
                table: "Users",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "UsersID4",
                table: "Movies",
                newName: "UsersId4");

            migrationBuilder.RenameColumn(
                name: "UsersID3",
                table: "Movies",
                newName: "UsersId3");

            migrationBuilder.RenameColumn(
                name: "UsersID2",
                table: "Movies",
                newName: "UsersId2");

            migrationBuilder.RenameColumn(
                name: "UsersID1",
                table: "Movies",
                newName: "UsersId1");

            migrationBuilder.RenameColumn(
                name: "UsersID",
                table: "Movies",
                newName: "UsersId");

            migrationBuilder.RenameIndex(
                name: "IX_Movies_UsersID4",
                table: "Movies",
                newName: "IX_Movies_UsersId4");

            migrationBuilder.RenameIndex(
                name: "IX_Movies_UsersID3",
                table: "Movies",
                newName: "IX_Movies_UsersId3");

            migrationBuilder.RenameIndex(
                name: "IX_Movies_UsersID2",
                table: "Movies",
                newName: "IX_Movies_UsersId2");

            migrationBuilder.RenameIndex(
                name: "IX_Movies_UsersID1",
                table: "Movies",
                newName: "IX_Movies_UsersId1");

            migrationBuilder.RenameIndex(
                name: "IX_Movies_UsersID",
                table: "Movies",
                newName: "IX_Movies_UsersId");

            migrationBuilder.RenameColumn(
                name: "MovieID",
                table: "CategoryMovies",
                newName: "MovieId");

            migrationBuilder.RenameColumn(
                name: "CategoryID1",
                table: "CategoryMovies",
                newName: "CategoryId1");

            migrationBuilder.RenameColumn(
                name: "CategoryID",
                table: "CategoryMovies",
                newName: "CategoryId");

            migrationBuilder.RenameColumn(
                name: "ID",
                table: "CategoryMovies",
                newName: "Id");

            migrationBuilder.RenameIndex(
                name: "IX_CategoryMovies_MovieID",
                table: "CategoryMovies",
                newName: "IX_CategoryMovies_MovieId");

            migrationBuilder.RenameIndex(
                name: "IX_CategoryMovies_CategoryID1",
                table: "CategoryMovies",
                newName: "IX_CategoryMovies_CategoryId1");

            migrationBuilder.RenameColumn(
                name: "ID",
                table: "Categories",
                newName: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_CategoryMovies_Categories_CategoryId1",
                table: "CategoryMovies",
                column: "CategoryId1",
                principalTable: "Categories",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_CategoryMovies_Movies_MovieId",
                table: "CategoryMovies",
                column: "MovieId",
                principalTable: "Movies",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Movies_Users_UsersId",
                table: "Movies",
                column: "UsersId",
                principalTable: "Users",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Movies_Users_UsersId1",
                table: "Movies",
                column: "UsersId1",
                principalTable: "Users",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Movies_Users_UsersId2",
                table: "Movies",
                column: "UsersId2",
                principalTable: "Users",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Movies_Users_UsersId3",
                table: "Movies",
                column: "UsersId3",
                principalTable: "Users",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Movies_Users_UsersId4",
                table: "Movies",
                column: "UsersId4",
                principalTable: "Users",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CategoryMovies_Categories_CategoryId1",
                table: "CategoryMovies");

            migrationBuilder.DropForeignKey(
                name: "FK_CategoryMovies_Movies_MovieId",
                table: "CategoryMovies");

            migrationBuilder.DropForeignKey(
                name: "FK_Movies_Users_UsersId",
                table: "Movies");

            migrationBuilder.DropForeignKey(
                name: "FK_Movies_Users_UsersId1",
                table: "Movies");

            migrationBuilder.DropForeignKey(
                name: "FK_Movies_Users_UsersId2",
                table: "Movies");

            migrationBuilder.DropForeignKey(
                name: "FK_Movies_Users_UsersId3",
                table: "Movies");

            migrationBuilder.DropForeignKey(
                name: "FK_Movies_Users_UsersId4",
                table: "Movies");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Users",
                newName: "ID");

            migrationBuilder.RenameColumn(
                name: "UsersId4",
                table: "Movies",
                newName: "UsersID4");

            migrationBuilder.RenameColumn(
                name: "UsersId3",
                table: "Movies",
                newName: "UsersID3");

            migrationBuilder.RenameColumn(
                name: "UsersId2",
                table: "Movies",
                newName: "UsersID2");

            migrationBuilder.RenameColumn(
                name: "UsersId1",
                table: "Movies",
                newName: "UsersID1");

            migrationBuilder.RenameColumn(
                name: "UsersId",
                table: "Movies",
                newName: "UsersID");

            migrationBuilder.RenameIndex(
                name: "IX_Movies_UsersId4",
                table: "Movies",
                newName: "IX_Movies_UsersID4");

            migrationBuilder.RenameIndex(
                name: "IX_Movies_UsersId3",
                table: "Movies",
                newName: "IX_Movies_UsersID3");

            migrationBuilder.RenameIndex(
                name: "IX_Movies_UsersId2",
                table: "Movies",
                newName: "IX_Movies_UsersID2");

            migrationBuilder.RenameIndex(
                name: "IX_Movies_UsersId1",
                table: "Movies",
                newName: "IX_Movies_UsersID1");

            migrationBuilder.RenameIndex(
                name: "IX_Movies_UsersId",
                table: "Movies",
                newName: "IX_Movies_UsersID");

            migrationBuilder.RenameColumn(
                name: "MovieId",
                table: "CategoryMovies",
                newName: "MovieID");

            migrationBuilder.RenameColumn(
                name: "CategoryId1",
                table: "CategoryMovies",
                newName: "CategoryID1");

            migrationBuilder.RenameColumn(
                name: "CategoryId",
                table: "CategoryMovies",
                newName: "CategoryID");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "CategoryMovies",
                newName: "ID");

            migrationBuilder.RenameIndex(
                name: "IX_CategoryMovies_MovieId",
                table: "CategoryMovies",
                newName: "IX_CategoryMovies_MovieID");

            migrationBuilder.RenameIndex(
                name: "IX_CategoryMovies_CategoryId1",
                table: "CategoryMovies",
                newName: "IX_CategoryMovies_CategoryID1");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Categories",
                newName: "ID");

            migrationBuilder.AddForeignKey(
                name: "FK_CategoryMovies_Categories_CategoryID1",
                table: "CategoryMovies",
                column: "CategoryID1",
                principalTable: "Categories",
                principalColumn: "ID");

            migrationBuilder.AddForeignKey(
                name: "FK_CategoryMovies_Movies_MovieID",
                table: "CategoryMovies",
                column: "MovieID",
                principalTable: "Movies",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Movies_Users_UsersID",
                table: "Movies",
                column: "UsersID",
                principalTable: "Users",
                principalColumn: "ID");

            migrationBuilder.AddForeignKey(
                name: "FK_Movies_Users_UsersID1",
                table: "Movies",
                column: "UsersID1",
                principalTable: "Users",
                principalColumn: "ID");

            migrationBuilder.AddForeignKey(
                name: "FK_Movies_Users_UsersID2",
                table: "Movies",
                column: "UsersID2",
                principalTable: "Users",
                principalColumn: "ID");

            migrationBuilder.AddForeignKey(
                name: "FK_Movies_Users_UsersID3",
                table: "Movies",
                column: "UsersID3",
                principalTable: "Users",
                principalColumn: "ID");

            migrationBuilder.AddForeignKey(
                name: "FK_Movies_Users_UsersID4",
                table: "Movies",
                column: "UsersID4",
                principalTable: "Users",
                principalColumn: "ID");
        }
    }
}

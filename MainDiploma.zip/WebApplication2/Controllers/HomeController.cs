﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using WebApplication2.Models;
using WebApplication2.Data;

namespace WebApplication2.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly Movie _context;

        private readonly User _user_context;

        public HomeController(ILogger<HomeController> logger, Movie context, User user_context)
        {
            _logger = logger;
            _context = context;
            _user_context = user_context;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Movies()
        {
            return View();
        }
        public IActionResult MyList()
        {
            return View();
        }
        public IActionResult TelevisionSeries()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Video()
        {
            return View();
        }
        public IActionResult Login()
        {
            return View();
        }
        public IActionResult Register()
        {
            return View();
        }
        public IActionResult Subscription()
        {
            return View();
        }
        public IActionResult FreeSubscription()
        {
            return View();
        }

        public IActionResult ExpensiveSubscription()
        {
            return View();
        }
        public IActionResult CAPTCHA()
        {
            return View();
        }
        public IActionResult Settings()
        {
            return View();
        }
        
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
       
        public IActionResult SaveRating(int movieId, int rating)
        {
            try
            {
                var movie = _context.Movies.FirstOrDefault(m => m.Id == movieId);

                if (movie != null)
                {
                    movie.Rating = rating;

                    _context.SaveChanges(); // Используем синхронный метод сохранения изменений

                    return Json(new { success = true, message = "Рейтинг успешно сохранен." });
                }
                else
                {
                    return Json(new { success = false, message = "Фильм не найден." });
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "Произошла ошибка при сохранении рейтинга.", error = ex.Message });
            }
        }

        public IActionResult AddUser(string name, string surname, string email, string password)
        {
            try
            {
                // Создаем нового пользователя
                var newUser = new User
                {
                    Name = name,
                    Surname = surname,
                    Email = email,
                    Password = password // В реальном приложении следует использовать хешированный пароль
                };

                // Добавляем пользователя в контекст базы данных
                _user_context.Users.Add(newUser);

                // Сохраняем изменения в базе данных
                _user_context.SaveChanges();

                return Json(new { success = true, message = "Пользователь успешно добавлен." });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "Произошла ошибка при добавлении пользователя.", error = ex.Message });
            }
        }

    }
}
Select CategoryName as Category 
from Category;
Insert into Category(CategoryName) values 
('Drama'),('Comedy'),('Action'),('Science fiction'),('Fantasy'),('Thriller'),
('Horror'),('Romance'),('Melodrama'),('Criminal'),('Historic'),('Documentary'),
('Horror Fiction'), ('Animation'),('Adventures');

--Delete from Category Where CategoryName >'A';

Select MovieName as Movie, CountryMaker, CategoryID, IsPremium, Year, Description 
from Movie;


Insert into Movie(MovieName, CountryMaker, CategoryID, IsPremium, Year, Description) values
('1917','The Great Britain',2,0,2019,'The film tells the story of two young soldiers who embark on a dangerous mission during the First World War. They must deliver an important message to save the lives of many soldiers.'),
('Cold War','France',2,0,2018,'This is a love story between a music director and a young singer, which unfolds against the backdrop of the Cold War and political turbulence'),
('The Bride','Norway',2,0,2020,'The film tells the story of a young Norwegian woman who enters into a fictitious marriage with an immigrant to help him obtain a residence permit, but soon their relationship becomes more complicated. '),
('Once upon a time... in Hollywood ','USA',2,0,2019,'This is a comedy about an actor and his stunt double trying to succeed in Hollywood in the late 1960s.'),
('The Barber of Laredo','Russia',2,0,2020,'A comedy about a hairdresser from a provincial town who dreams of opening his own salon in Vienna.'),
('Little Women','USA',7,0,2019,'The film, based on the novel by Louisa May Alcott, tells about the lives of four sisters and their desire for self-realization in the middle of the XIX century.'),
('A Couple from the Future','USA',7,0,2020,'This is a thriller about a couple who discover that there is a secret hidden in their house related to their future.'),
('"Seven Lives','USA',7,0,2008,'In this film, Will Smith plays the role of a man who decides to change the fate of seven strangers by doing virtuous deeds.'),
('Venom','USA',14,0,2018,'This is a film about a journalist who becomes the master of an alien symbiote, which leads to the creation of the superhero personality Venom.'),
('Tenet','USA',14,0,2020,'Director Christopher Nolan presents a sci-fi thriller that investigates an international espionage organization capable of manipulating time.'),
('Ghosts of the Red Kingdom','China',14,0,2019 ,'It is a Chinese fantasy action game in which the protagonist fights demons and evil forces to protect the world.'),
('It: Chapter 2','Canada',8,1,2019 ,'It is a sequel to the film version of Stephen Kings book about Pennywise the Clown and his victims, who grow up and return to their hometown for the ultimate battle.'),
('Invicible Man','USA',8,1,2019,'This is a sci-fi thriller about a woman who suspects that her ex-boyfriend has gained invisibility and started stalking her.'),
('The Executioner','Russia',8,1,2020,'Russian horror about a mysterious executioner who avenges atrocities and commits terrible murders.'),
('Journey to the Center of the Earth','USA',16,0,2008,'Based on the classic book by Jules Verne, the film follows a group of explorers descending into the bowels of the Earth.'),
('Fast & Furious: Hobbs & Shaw','USA',16,0,2019,'This is a spin-off of the Fast & Furious franchise in which the two main characters team up to stop a bioterrorist.'),
('Jumanji: The Next Level','USA',16,1,2019,'Continuation of the adventure saga "Jumanji", in which a group of friends find themselves in a dangerous video game.'),
('Joker','USA',4,1,2019,'The film tells the story of Batmans famous archenemy, the Joker, and his path to crime.'),
('Bloodshot ','USA',4,1,2020,'This is a fantastic action movie about a soldier resurrected with the help of advanced technology and capable of self-healing.'),
('Black Vidovs','USA',4,1,2021,'The film tells the story of a special agent who becomes the target of killers and is forced to fight for her life.'),
('A Clockwork Orange','USA',10,1,1971,'This is an adaptation of the cult novel by Anthony Burgess, telling about a young criminal in a dystopian future.'),
('American Beauty','USA',10,1,1999,'The film follows the lives of neighbors in the suburbs, revealing hidden problems and their impact on their families.'),
('Skyline','USA',10,1,2010,'This is a sci-fi melodrama about a group of people trying to survive after an alien attack. I hope that these descriptions have helped you better understand the plots and atmosphere of each of the films.'),
('Maleficent: Mistress of Darkness','USA',6,1,2019,'It is a sequel to the movie "Maleficent" and follows the complicated relationship between Maleficent and Princess Aurora as they face new threats and mysterious powers.'),
('Lone Wolf','USA',6,1,2020,'This fantasy film tells the story of a young woman who has the unique ability to bond with wolves and must protect her people from dangerous enemies.'),
('Wonder Woman 1984','USA',6,1,2020 ,'The second part of the story is about Wonder Woman, Diana Prince, who faces new enemies and a mysterious man-made object that grants wishes, but with dangerous consequences.'),
('Future World: Season 1','The Great Britain',13,1,2020,'This docuseries explores the future of our planet and the technological innovations that could change the world.'),
('Planet Earth II','The Great Britain',13,1,2016,'This docuseries offers amazing footage of nature and life on Earth, highlighting the diversity of ecosystems. '),
('Apollo 11','USA',13,1,2019,'The film documents the first successful mission to the moon, Apollo 11, by providing unique archival material and telling the story of this epic expedition.'),
('The Irishman','USA',11,1,2019,'Martin Scorseses film tells the story of Frank Sheeran, an assassin and best friend of Jimmy Hoffa, a union leader, and his connection to organized crime.'),
('Gentlemen','The Great Britain',11,1,2019,'This is a crime comedy about a British drug lord who gets into a complex intrigue when he decides to sell his drug business. '),
('Especially Dangerous','USA',11,0,2019,'The film tells the story of a former special agent who engages in a fight with dangerous mercenaries to save his daughter. '),
('Toy Story 4','USA',15,0,2019,'The fourth installment of the popular franchise about the adventures of toys who find themselves in a new home environment and face new friends and challenges.'),
('Frozen II','USA',15,0,2019,'Continuation of the animated saga about the adventures of Elsa and Anna in the world of magic, where they try to unravel the past and the true origin of their abilities.'),
('The Flying Ship','Germany',15,0,2021,'An animated film about the adventures of a young dragon who embarks on a journey on a flying ship to find his place in the world.'),
('Completed Portrait','The Great Britain',9,1,2019,'This film tells about the life of the artist and his connection with the portrait painter in an era of turbulent creativity and passionate relationships.'),
('Fifty Shades Darker','USA',9,1,2017,'The second part of the story is about the complex relationship between Anastacia Steele and Christian Gray, including new challenges and mysteries.'),
('Upgrade','Australia',9,1,2018,'This is a fantastic melodrama about a man who received an innovative implant that improves his physical abilities, but changes his life.'),
('Bohemian Rhapsody','The Great Britain',10,1,2018,'A biopic about the legendary rock band Queen and its vocalist Freddie Mercury.'),
('Caravan','USA',10,1,2020,'This is a musical drama about musicians traveling around America and their desire for success. '),
('Happy Ending','Bharat',10,1,2019,'This is a musical romantic comedy about a young couple trying to organize a wedding in the context of family traditions.'),
('Joe Jo Rabbit','New Zealand',12,0,2019 ,'This is a comedy about a boy whose imaginary friendship with Hitler is shattered when he discovers that his mother is hiding a Jewish girl in their home during World War II.'),
('Capernaum: City of God','France',12,1,2018,'The film tells the story of a 12-year-old boy who fled his home and was subjected to severe ordeal on the streets of Beirut.');

Select UserName, Age, IsPremium
from Users;
Insert into Users(UserName, Age, IsPremium) values 
('MovieBuff',19,0),('GamerGeek',20,0),('TravelExplorer',21,0),('FoodieFanatic',22,0),('MusicLover',25,0),('FitnessFreak',27,0),('ArtEnthusiast',29,0),
('TechGuru',32,0),('Bookworm',34,0),('NatureAdventurer',36,0),('Fashionista',37,0),('DIYMaster',38,0),('SportsFan',43,0),('PetLover',45,1),
('ScienceNerd',47,1),('CookingPro',49,1),('WellnessWarrior',54,1),('HistoryBuff',56,1),('YogaYogi',59,1),('PoetryPioneer',65,1),('CreativeCreator',78,1);






















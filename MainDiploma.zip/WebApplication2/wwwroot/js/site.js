﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.



function toggleForm() {
    var form = document.getElementById("myForm");
    if (form.style.display === "none") {
        form.style.display = "block";
    } else {
        form.style.display = "none";
    }
}

async function CreateUser() {
    const Name = document.getElementById('name').value;
    const Email = document.getElementById('email').value;

    try {
        const answer = await fetch('/create-user', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ Name, Email }),
        });

        if (MessageEvent.ok) {
            console.log('Пользователь успешно создан');
        } else {
            console.error('Ошибка при создании пользователя');
        }
    } catch (Error) {
        console.error(Error);
    }
}

const express = require('express');
const bodyParser = require('body-parser');
const sql = require('mssql');

const app = express();
const порт = 7258;

// Конфигурация подключения к SQL Server
const config = {
    user: 'DESKTOP-H58PEGV/Lenovo',
    password: 'ваш_пароль',
    server: 'DESKTOP-H58PEGV',
    database: 'StrimingService',
    options: {
        encrypt: true, // Для использования шифрования
    },
};

app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

app.post('/create-user', async (req, res) => {
    const { Name, Email } = req.body;

    try {
        // Подключение к базе данных
        await sql.connect(config);

        // Запрос на вставку нового пользователя
        const req = new sql.Request();
        req.input('Name', sql.NVarChar, имя);
        req.input('Email', sql.NVarChar, email);
        
        const result = await запрос.query('INSERT INTO Пользователи (Name, Email) VALUES (@Name, @Email)');
        console.log('Пользователь сохранен:', result);

        res.sendStatus(200);
    } catch (Error) {
        console.error(Error);
        res.sendStatus(500);
    } finally {
        // Закрытие соединения
        await sql.close();
    }
});

app.listen(порт, () => {
    console.log(`Сервер запущен на порту ${порт}`);
});

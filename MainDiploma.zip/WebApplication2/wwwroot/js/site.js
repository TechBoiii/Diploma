﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

var redirect_btn = document.getElementById('redirect_btn');
var email = document.getElementById('email');
var password = document.getElementById('password');
var btn_save = document.getElementById('btn_save');
var btn_exit = document.getElementById('btn_exit');
var cancel_sub_btn = document.getElementById('cancel_sub_btn');
var Name = document.getElementById('name');
var surname = document.getElementById('surname');
var next_btn = document.getElementById('next_btn');
var btn_pay_sub = document.getElementById('btn_pay_sub');
var btn_free_sub = document.getElementById('btn_free_sub');

redirect_btn.addEventListener('click', function () {

    window.location.href = 'Subscription';
});
next_btn.addEventListener('click', function () {
    window.location.href = 'FreeSubscription';
    
});
btn_save.addEventListener('click', function () {

    window.location.href = 'Movies';
    
});

btn_exit.addEventListener('click', function () {
    window.location.href = 'Movies';
});

cancel_sub_btn.addEventListener('click', function () {
    window.location.href = 'Subscription';
});

btn_free_sub.addEventListener('click', function () {
    window.location.href = 'Movies';

});

btn_pay_sub.addEventListener('click', function () {
    window.location.href = 'Movies';

    
});



$(document).ready(function () {
    // Пример: при изменении рейтинга отправляем данные на сервер
    console.log("Script is running");
    $('.simple-rating_item').on('change', function () {
        var movieId = $(this).data('movie-id'); // предположим, что у вас есть атрибут data-movie-id для идентификации фильма
        var rating = $(this).val();

        // Отправка данных на сервер с использованием AJAX
        $.ajax({
            url: '/HomeController/SaveRating', // Замените на свой путь к контроллеру
            type: 'POST',
            data: { movieId: movieId, rating: rating },
            success: function (data) {
                if (data.success) {
                    alert(data.message);
                } else {
                    alert('Произошла ошибка при сохранении рейтинга.');
                }
            },
            error: function () {
                alert('Произошла ошибка при отправке запроса.');
            }
        });
    });
});
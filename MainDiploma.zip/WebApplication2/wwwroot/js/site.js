﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.



function toggleForm() {
    var form = document.getElementById("myForm");
    if (form.style.display === "none") {
        form.style.display = "block";
    } else {
        form.style.display = "none";
    }
}

async function CreateUser() {
    const Name = document.getElementById('name').value;
    const Email = document.getElementById('email').value;

    try {
        const ответ = await fetch('/create-user', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ Name, Email }),
        });

        if (MessageEvent.ok) {
            console.log('Пользователь успешно создан');
        } else {
            console.error('Ошибка при создании пользователя');
        }
    } catch (Error) {
        console.error(Error);
    }
}
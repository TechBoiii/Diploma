﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

var redirect_btn = document.getElementById('redirect_btn');
var email = document.getElementById('email');
var password = document.getElementById('password');
var btn_save = document.getElementById('btn_save');
var btn_exit = document.getElementById('btn_exit');
var cancel_sub_btn = document.getElementById('cancel_sub_btn');
var Name = document.getElementById('name');
var surname = document.getElementById('surname');
var next_btn = document.getElementById('next_btn');
var btn_pay_sub = document.getElementById('btn_pay_sub');
var btn_free_sub = document.getElementById('btn_free_sub');

redirect_btn.addEventListener('click', function () {

    window.location.href = 'Subscription';
});
next_btn.addEventListener('click', function () {
    window.location.href = 'FreeSubscription';
    
});
btn_save.addEventListener('click', function () {

    window.location.href = 'Movies';
    
});

btn_exit.addEventListener('click', function () {
    window.location.href = 'Movies';
});

cancel_sub_btn.addEventListener('click', function () {
    window.location.href = 'Subscription';
});

btn_free_sub.addEventListener('click', function () {
    window.location.href = 'Movies';

});

btn_pay_sub.addEventListener('click', function () {
    window.location.href = 'Movies';

    
});



$(document).ready(function () {
    // Пример: при изменении рейтинга отправляем данные на сервер
    console.log("Script is running");
    $('.simple-rating_item').on('change', function () {
        var movieId = $(this).data('movie-id'); // предположим, что у вас есть атрибут data-movie-id для идентификации фильма
        var rating = $(this).val();

        // Отправка данных на сервер с использованием AJAX
        $.ajax({
            url: '/HomeController/SaveRating', // Замените на свой путь к контроллеру
            type: 'POST',
            data: { movieId: movieId, rating: rating },
            success: function (data) {
                if (data.success) {
                    alert(data.message);
                } else {
                    alert('Произошла ошибка при сохранении рейтинга.');
                }
            },
            error: function () {
                alert('Произошла ошибка при отправке запроса.');
            }
        });
    });
});


const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));

// create connection to database
const db = mysql.createConnection({
    host: 'DESKTOP-H58PEGV',
    user: 'DESKTOP-H58PEGV/Lenovo',
    password: '',
    database: 'StrimingService'
});

// connect to database
db.connect((err) => {
    if (err) throw err;
    console.log('MySql Connected...');
});

app.get('/', (req, res) => {
    res.sendFile(__dirname + 'Index.html');
});

app.post('/Add_user', (req, res) => {
    const Name = req.body.Name;
    const Surname = req.body.Surname;
    const Email = req.body.Email;
    const Password = req.body.Password;

    const sql = `INSERT INTO Users (name, surname, email, password) VALUES ('${Name}', '${Surname}', '${Email}', '${Password}')`;
    const values = [Name, Surname, Email, Password];

    let query = db.query(sql, values, (err, result) => {
        if (err) throw err;
        console.log(result);
        res.send('User information added to the database...');
    });
});

app.listen('7105', () => {
    console.log('Server started on port 7105');
});